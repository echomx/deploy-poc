from pecan import expose, request
import os
import logging
from extend import Extendvolume
import subprocess
import time


logger = logging.getLogger(__name__)


class NfsController(object):
    @expose('json')
    def create(self, **kw):
        try:
            assert kw['volName']
            assert kw['volSize']
            path = os.path.join('/nfs', kw['volName'])
            if os.path.exists(path):
                return {'Other': 'Dir already exist', 'code': -1}
            elif not os.path.exists(path):
                os.popen("/opt/convert2nfs/bin/create-nfs-xfs.sh " + kw['volName'] + " " + kw['volSize'])
                if os.path.exists(path):
                    return {'Success': 'Directory has been created','code':0}
                else:
                    return {'Failed': 'Directory has not been created','code': -2}
        except Exception, e:
            logger.exception(e)
            return {'Error': 'Please check API url,or watch logs','code': -3}

    @expose('json')
    def delete(self, **kw):
        try:
            assert kw['volName']
            path = os.path.join('/nfs', kw['volName'])
            if not os.path.exists(path):
                return {'Other': 'Dir not exist'}
            elif os.path.exists(path) and kw['volName'] != '':
                subprocess.call('/opt/convert2nfs/bin/delete-nfs.sh %s' % (kw['volName']), shell=True)
                if os.path.exists(path):
                    with open('unnecessaryvolume', 'a+') as f:
                        f.writelines([kw['volName'], '\n'])
                        logger.info('volume %s marked deleted' % kw['volName'])
                        return {'Success': 'Dir has been deleted'}
                else:
                    logger.info('volume %s has been deleted' % kw['volName'])
                    return {'Success': 'Dir has been deleted'}
        except Exception, e:
            logger.exception(e)
            return {'Error': 'Please check API url,or watch logs'}

    @expose('json')
    def upload(self, **kw):
        try:
            assert kw['volName']
            assert kw['fileName']
            filepath = '/nfs/%s/%s' % (kw['volName'], kw['fileName'])
            if request.method == 'OPTIONS':
                return
            if kw['volName'] == 'promrule':
                data = request.POST['file'].file.read()
                with open(filepath, 'wb') as f:
                    f.write(data)
                if os.path.exists(filepath):
                    return {'Success': 'Upload'}
                else:
                    return {'Failed': 'Not upload'}
            # elif os.path.exists(filepath):
            #     return {'Failed': 'File already exist'}
            else:
                data = request.POST['file'].file.read()
                try:
                    with open(filepath, 'wb') as f:
                        f.write(data)
                except IOError, msg:
                    logger.exception(msg)
                    if 'No space left on device' in msg:
                        print msg
                        os.remove(filepath)
                        return {'Failed': 'File is oversize'}
                if os.path.exists(filepath):
                    return {'Success': 'Upload'}
                else:
                    return {'Failed': 'Not upload'}
        except Exception, e:
            logger.exception(e)
            return {'Error': 'Please check API url,or watch logs'}

    @expose('json')
    def deletefile(self, **kw):
        filepath = '/nfs/%s/%s' % (kw['volName'], kw['fileName'])
        if os.path.exists(filepath):
            os.remove(filepath)
        if os.path.exists(filepath):
            return {'Failed': 'File exist'}
        else:
            return {'Success': 'File already deleted'}



class WapiController(object):
    
    nfs = NfsController()
    nfs4hk = NfsController()


class RootController(object):

    @expose('json', route='rbd')
    def index(self):
        d = dict()
        d['key'] = 'value'
        return d

    nfs = NfsController()
    nfs4hk = NfsController()
    wapi = WapiController()
    volume = Extendvolume()
