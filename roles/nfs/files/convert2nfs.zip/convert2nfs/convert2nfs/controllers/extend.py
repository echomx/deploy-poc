from pecan import expose
import os
import lvm2py
import logging
import subprocess


logger = logging.getLogger(__name__)

prometheus = {'bj': 'http://prometheus.caas.haihangyun.cn', 'hk': 'http://prometheus.haihangyun.cn', 'test': 'http://prometheus.tcaas.cn'}


class Extendvolume(object):

    @expose('json')
    def extendvol(self, **kw):
        try:
            assert kw['volName']
            assert kw['extendSize']
            assert int(kw['extendSize']) % 512 == 0
            volsize = lvm2py.LVM().get_vg('vg-paas', 'r').get_lv(kw['volName']).size(units='MiB')
            lvexcode = subprocess.call('lvextend -L %sb /dev/mapper/vg--paas-%s' % (kw['extendSize'], kw['volName']), shell=True)
            if lvexcode != 0:
                return {'Failed': 'lvextend exec failed'}
            upsize = lvm2py.LVM().get_vg('vg-paas', 'r').get_lv(kw['volName']).size(units='MiB')
            if int(upsize) > int(volsize):
                execode = subprocess.call('xfs_growfs /dev/mapper/vg--paas-%s' % (kw['volName']), shell=True)
                if execode == 0:
                    return {'Success': 'Extend to %s' % upsize}
                else:
                    return {'Failed': 'Plz check log'}
        except Exception, e:
            logger.exception(e)
            return {'Error': 'Please check API url,or watch logs'}
