from pecan import expose
import lvm2py


class Harecovery(object):

    @expose('json')
    def recoverylv(self):
        lvname_list = []
        lvob = lvm2py.LVM().get_vg('vg-paas').lvscan()
        for i in lvob:
            lvname_list.append(i.name)
        with open('/nfs/convert2nfs/recoverylvname') as f:
            f.write(lvname_list)
        return {'Success': 'Recovery lv name in file /nfs/convert2nfs/recoverylvname'}


