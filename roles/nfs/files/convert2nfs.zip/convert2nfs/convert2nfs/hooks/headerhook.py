from pecan import response
from pecan.hooks import PecanHook


class AddheaderHook(PecanHook):
    def after(self, state):
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'POST, GET, OPTIONS, DELETE'
        response.headers[
            'Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
        print '\nrequest method:%s' % state.request.method
        print '\nresponse status:%s' % state.response.status
