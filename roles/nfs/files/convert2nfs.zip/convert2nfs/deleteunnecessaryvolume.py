import lvm2py
import os
import time
import subprocess
import shutil
import traceback
import logging
# def getlvname():
#     lvob = lvm2py.LVM().get_vg('vg-paas').lvscan()
#     with open('lvname-%s' % time.strftime('%Y-%m-%d-%H:%M:%S', time.localtime()), 'w') as f:
#         for i in lvob:
#             f.write(i.name)
#         return 'Get lvname OK'

logging.basicConfig(level=logging.INFO,
                    filename='/opt/convert2nfs/Running.log',
                    filemode='a',
                    format='%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s')

logger = logging.getLogger(__name__)

def handleunnecessaryvolume(volName):
    umount_code = subprocess.call('umount /nfs/%s' % volName, shell=True)
    if umount_code != 0:
        print '%s Umount failed' % volName
    if not os.path.ismount('/nfs/%s' % volName):
        shutil.rmtree('/nfs/%s' % volName)
    if os.path.exists('/nfs/%s' % volName):
        print '%s Remove files failed' % volName
    else:
        vg = lvm2py.LVM().get_vg('vg-paas', 'w')
        lv = vg.get_lv(volName)
        vg.remove_lv(lv)
        subprocess.call('sed -i "/%s/d" /etc/exports' % volName, shell=True)
        print '%s clear success' % volName



def getalllvname():
    lvname = []
    lvob = lvm2py.LVM().get_vg('vg-paas').lvscan()
    for i in lvob:
        lvname.append(i.name)
    return lvname


def getunnecessaryvolume():
    # try:
    rmlist = []
    with open('/opt/convert2nfs/unnecessaryvolume') as f:
        for volName in f.readlines():
            if volName.strip():
                handleunnecessaryvolume(volName.strip())
                rmlist.append(volName.strip())
    rmfailed = list(set(getalllvname()) & set(rmlist))
    rmsuccess = list(set(rmlist).difference(set(rmfailed)))
    logger.info('%s has been deleted' % rmsuccess)
    with open('/opt/convert2nfs/unnecessaryvolume', 'w') as f1:
        for i in rmfailed:
            f1.write(i)
            f1.write('\n')
    return 'Tomorrow again'
    # except Exception, e:
    #     print logging.error(e)

def checkvolume():
    deletevol = []
    with open('/opt/convert2nfs/unnecessaryvolume') as f:
        for volName in f.readlines():
            deletevol.append(volName.strip())
    existvol = list(set(getalllvname()) & set(deletevol))
    print existvol
    with open('/opt/convert2nfs/unnecessaryvolume', 'w') as f1:
        for i in existvol:
            f1.write(i)
            f1.write('\n')


if __name__ == '__main__':
    checkvolume()
    getunnecessaryvolume()