from convert2nfs.hooks.headerhook import AddheaderHook

#sys.path.append('/nfs/convert2nfs/convert2nfs/hooks/headerhook.py')


# Server Specific Configurations
server = {
    'port': '80',
    'host': '0.0.0.0'
}

# Pecan Application Configurations
app = {
    'root': 'convert2nfs.controllers.root.RootController',
    'modules': ['convert2nfs'],
    'static_root': '%(confdir)s/public',
    'template_path': '%(confdir)s/convert2nfs/templates',
    'debug': False,
    'errors': {
        404: '/error/404',
        '__force_dict__': True
    },
    'hooks': [AddheaderHook()]
}

logging = {
    'root': {'level': 'INFO', 'handlers': ['logfile']},
    'loggers': {
        'convert2nfs': {'level': 'INFO', 'handlers': ['logfile'], 'propagate': False},
        'pecan': {'level': 'DEBUG', 'handlers': ['console'], 'propagate': False},
        'py.warnings': {'handlers': ['logfile']},
        '__force_dict__': True
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'color'
        },
        'logfile': {
            'class': 'logging.FileHandler',
            'filename': '/opt/convert2nfs/Running.log',
            'level': 'DEBUG',
            'formatter': 'color'
        }
    },
    'formatters': {
        'simple': {
            'format': ('%(asctime)s %(levelname)-5.5s [%(name)s]'
                       '[%(threadName)s] %(message)s')
        },
        'color': {
            '()': 'pecan.log.ColorFormatter',
            'format': ('%(asctime)s [%(padded_color_levelname)s] [%(name)s]'
                       '[%(threadName)s] %(message)s'),
        '__force_dict__': True
        }
    }
}

# Custom Configurations must be in Python dictionary format::
#
# foo = {'bar':'baz'}
#
# All configurations are accessible at::
# pecan.conf
